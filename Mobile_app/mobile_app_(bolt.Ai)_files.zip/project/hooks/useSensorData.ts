import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

export interface SensorData {
  temperature: number;
  humidity: number;
  moisture: number;
  ph: number;
}

const supabase = createClient(
  process.env.EXPO_PUBLIC_SUPABASE_URL!,
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!
);

export function useSensorData() {
  const [data, setData] = useState<SensorData>({
    temperature: 0,
    humidity: 0,
    moisture: 0,
    ph: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const syncAndFetch = async () => {
      try {
        const syncUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/sync-firebase-to-supabase`;
        const syncResponse = await fetch(syncUrl);

        if (!syncResponse.ok) {
          console.warn('Sync function returned non-200:', syncResponse.status);
        } else {
          const syncResult = await syncResponse.json();
          console.log('Sync result:', syncResult);
        }

        const { data: sensorData, error: err } = await supabase
          .from('sensor_data')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (err) {
          console.error('Supabase error:', err);
          setError('Failed to fetch data: ' + err.message);
          setLoading(false);
          return;
        }

        if (sensorData) {
          console.log('Latest sensor data:', sensorData);
          setData({
            temperature: sensorData.temperature || 0,
            humidity: sensorData.humidity || 0,
            moisture: sensorData.moisture || 0,
            ph: sensorData.ph || 0,
          });
          setError(null);
        } else {
          setError('No sensor data available');
        }
        setLoading(false);
      } catch (err) {
        console.error('Error:', err);
        setError('Connection error: ' + (err as Error).message);
        setLoading(false);
      }
    };

    syncAndFetch();

    const channel = supabase
      .channel('sensor_data_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'sensor_data' },
        (payload) => {
          console.log('Real-time update received:', payload);
          const newRecord = payload.new as any;
          if (newRecord) {
            setData({
              temperature: newRecord.temperature || 0,
              humidity: newRecord.humidity || 0,
              moisture: newRecord.moisture || 0,
              ph: newRecord.ph || 0,
            });
            setError(null);
          }
        }
      )
      .subscribe();

    const interval = setInterval(syncAndFetch, 3000);

    return () => {
      clearInterval(interval);
      supabase.removeChannel(channel);
    };
  }, []);

  return { data, loading, error };
}
