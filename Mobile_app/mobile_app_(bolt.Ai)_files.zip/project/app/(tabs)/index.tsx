import { View, Text, StyleSheet, ScrollView, RefreshControl, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import SensorCard from '@/components/SensorCard';
import { useSensorData } from '@/hooks/useSensorData';

export default function HomeScreen() {
  const { data, loading, error } = useSensorData();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#22c55e" />
        <Text style={styles.loadingText}>Connecting to sensors...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#22c55e']} />
        }>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Live Sensor Data</Text>
          <Text style={styles.headerSubtitle}>Real-time monitoring</Text>
        </View>

        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}

        <View style={styles.cardsContainer}>
          <SensorCard
            title="Temperature"
            value={data.temperature}
            unit="°C"
            icon="🌡️"
            colors={['#f59e0b', '#f97316']}
          />

          <SensorCard
            title="Humidity"
            value={data.humidity}
            unit="%"
            icon="💧"
            colors={['#3b82f6', '#2563eb']}
          />

          <SensorCard
            title="Soil Moisture"
            value={data.moisture}
            unit="%"
            icon="🌱"
            colors={['#22c55e', '#16a34a']}
          />

          <SensorCard
            title="pH Level"
            value={data.ph}
            unit=""
            icon="⚗️"
            colors={['#8b5cf6', '#7c3aed']}
          />
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>Data updates automatically</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f3f4f6',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#6b7280',
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6b7280',
  },
  errorContainer: {
    backgroundColor: '#fee2e2',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  errorText: {
    color: '#dc2626',
    fontSize: 14,
  },
  cardsContainer: {
    marginBottom: 16,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  footerText: {
    fontSize: 14,
    color: '#9ca3af',
    fontStyle: 'italic',
  },
});
