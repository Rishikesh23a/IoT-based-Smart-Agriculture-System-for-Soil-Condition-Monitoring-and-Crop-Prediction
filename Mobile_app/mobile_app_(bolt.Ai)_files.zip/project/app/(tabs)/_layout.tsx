import { Tabs } from 'expo-router';
import { Sprout } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: true,
        headerStyle: {
          backgroundColor: '#22c55e',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        tabBarActiveTintColor: '#22c55e',
        tabBarInactiveTintColor: '#6b7280',
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Smart Agriculture',
          tabBarIcon: ({ size, color }) => (
            <Sprout size={size} color={color} />
          ),
          tabBarLabel: 'Sensors',
        }}
      />
    </Tabs>
  );
}
