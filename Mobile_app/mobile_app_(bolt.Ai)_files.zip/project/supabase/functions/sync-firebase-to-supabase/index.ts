import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const firebaseUrl = Deno.env.get("EXPO_PUBLIC_FIREBASE_DATABASE_URL");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!firebaseUrl || !supabaseUrl || !supabaseKey) {
      return new Response(
        JSON.stringify({
          error: "Missing environment variables",
        }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    console.log("Fetching from Firebase...");
    const firebaseResponse = await fetch(`${firebaseUrl}.json`, {
      method: "GET",
    });

    if (!firebaseResponse.ok) {
      throw new Error(`Firebase fetch failed: ${firebaseResponse.status}`);
    }

    const firebaseData = await firebaseResponse.json();
    console.log("Firebase data fetched successfully");

    if (!firebaseData?.SmartFarm?.Readings) {
      return new Response(
        JSON.stringify({ message: "No SmartFarm/Readings data in Firebase" }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const readings = firebaseData.SmartFarm.Readings;
    const timestamps = Object.keys(readings).map(Number).sort((a, b) => b - a);

    if (timestamps.length === 0) {
      return new Response(
        JSON.stringify({ message: "No readings found" }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const latestTimestamp = timestamps[0];
    const latestReading = readings[latestTimestamp];
    const sensorData = latestReading.SmartAgri || latestReading;

    const temperature = parseFloat(String(sensorData.Temperature || 0)) || 0;
    const humidity = parseFloat(String(sensorData.Humidity || 0)) || 0;
    const moisture = parseFloat(String(sensorData.Moisture || 0)) || 0;
    const ph = parseFloat(String(sensorData.pH || 0)) || 0;

    console.log("Extracted sensor data:", { temperature, humidity, moisture, ph });

    console.log("Syncing to Supabase...");
    const supabaseResponse = await fetch(
      `${supabaseUrl}/rest/v1/sensor_data`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${supabaseKey}`,
          apikey: supabaseKey,
        },
        body: JSON.stringify({
          temperature,
          humidity,
          moisture,
          ph,
        }),
      }
    );

    if (!supabaseResponse.ok) {
      const errorText = await supabaseResponse.text();
      console.error("Supabase sync error:", errorText);
      throw new Error(`Supabase insert failed: ${supabaseResponse.status}`);
    }

    const result = JSON.stringify({
      success: true,
      message: "Data synced successfully",
      sensorData: {
        temperature,
        humidity,
        moisture,
        ph,
      },
      timestamp: new Date().toISOString(),
    });

    return new Response(result, {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Sync error:", error);
    return new Response(
      JSON.stringify({
        error: "Sync failed",
        message: (error as Error).message,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
