/*
  # Create sensor_data table

  1. New Tables
    - `sensor_data`
      - `id` (uuid, primary key)
      - `temperature` (float)
      - `humidity` (float)
      - `moisture` (float)
      - `ph` (float)
      - `created_at` (timestamp)
  2. Security
    - Enable RLS on `sensor_data` table
    - Add policy for public read access
*/

CREATE TABLE IF NOT EXISTS sensor_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  temperature float NOT NULL DEFAULT 0,
  humidity float NOT NULL DEFAULT 0,
  moisture float NOT NULL DEFAULT 0,
  ph float NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sensor_data ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read sensor data"
  ON sensor_data FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert sensor data"
  ON sensor_data FOR INSERT
  WITH CHECK (true);
