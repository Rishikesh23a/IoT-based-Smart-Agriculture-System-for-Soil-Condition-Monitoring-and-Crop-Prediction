import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY || 'AIzaSyAUxLwgUALpPcWpp7_5GwHyNHsgNJQO3O8',
  databaseURL: process.env.EXPO_PUBLIC_FIREBASE_DATABASE_URL || 'https://smart-agriculture-df146-default-rtdb.firebaseio.com/',
};

console.log('Firebase Config:', {
  apiKey: firebaseConfig.apiKey ? 'present' : 'missing',
  databaseURL: firebaseConfig.databaseURL
});

const app = initializeApp(firebaseConfig);
export const database = getDatabase(app);
console.log('Firebase initialized successfully');
